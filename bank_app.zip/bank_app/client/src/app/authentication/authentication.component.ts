import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-authentication',
  template: `    
	<router-outlet></router-outlet>    
  `,
})
export class AuthenticationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
