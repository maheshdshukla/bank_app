import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {HttpClientModule} from '@angular/common/http';
import { TransactionComponent ,TransferComponent } from './layouts';
import { FooterComponent, HeaderComponent  } from './common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatButtonModule,
  MatFormFieldModule,
  MatButtonToggleModule,
  MatIconModule,
  MatInputModule,
  MatRippleModule,
  MatTableModule
} from '@angular/material';

let material = [   
  MatButtonModule,
  MatFormFieldModule,
  MatButtonToggleModule,
  MatIconModule,
  MatRippleModule,
  MatInputModule,
  MatTableModule
  ];

const TEMPLATE_COMPONENTS = [
  TransactionComponent, TransferComponent, FooterComponent,HeaderComponent
];

@NgModule({
  declarations: [...TEMPLATE_COMPONENTS],
  exports : [...TEMPLATE_COMPONENTS,FormsModule, ...material,
    ReactiveFormsModule],
  imports: [
    CommonModule,HttpClientModule,FormsModule, ReactiveFormsModule,...material
  ]
})
export class TemplateModule { }
