import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from  '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'transfer',
  templateUrl: './transfer-layout.component.html',
  styleUrls: ['./transfer-layout.component.css']
})
export class TransferComponent implements OnInit {

  paymentForm: FormGroup;
    submitted = false;

    constructor(private formBuilder: FormBuilder, private http: HttpClient, private route: Router) {}
		
    ngOnInit() {
        this.paymentForm = this.formBuilder.group({
            from: ['', [Validators.required,Validators.minLength(10),Validators.maxLength(10),Validators.pattern(/^[0-9]\d*$/)]],
            to: ['', [Validators.required,Validators.minLength(10),Validators.maxLength(10),Validators.pattern(/^[0-9]\d*$/)]],
			amount: ['', [Validators.required,Validators.min(100),Validators.max(20000),Validators.pattern(/^[0-9]\d*$/)]],
        });
    }

    // convenience getter for easy access to form fields
    get f() { return this.paymentForm.controls; }

    onSubmit() {

        // stop here if form is invalid
        if (this.paymentForm.invalid) {
            return;
        }
		if(this.paymentForm.value.to == this.paymentForm.value.from){
			alert('Warning!! :-)\n\n' + "Both account number should not be same");
			return;
		}

		this.http.post<any>('http://localhost:8090/bank-app/accounts/', { from: this.paymentForm.value.from, to:this.paymentForm.value.to, amount:this.paymentForm.value.amount		}).subscribe(data => {
			alert('SUCCESS!! :-)\n\n');
			this.route.navigate(["/transaction"]);
        })		       
    }

}
