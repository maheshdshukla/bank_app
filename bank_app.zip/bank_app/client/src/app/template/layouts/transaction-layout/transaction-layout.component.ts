import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';


export interface PeriodicElement {
  account: string;  
  credit: string;
  debit:string;
  total: string;
  date: string;
}

const ELEMENT_DATA: any = [];

@Component({
  selector: 'transaction',
  templateUrl: './transaction-layout.component.html',
  styleUrls: ['./transaction-layout.component.css']
})
export class TransactionComponent implements OnInit {

	displayedColumns: string[] = ['account','credit','debit', 'total', 'date'];
	dataSource = ELEMENT_DATA;
	transactionForm: FormGroup;

  constructor(private formBuilder: FormBuilder,private http: HttpClient) {
  
	
  }
  
  get f() { return this.transactionForm.controls; }

  ngOnInit() {
	this.transactionForm = this.formBuilder.group({
            account: ['9555947583', [Validators.required,Validators.minLength(10),Validators.maxLength(10),Validators.pattern(/^[0-9]\d*$/)]]            
        });
		this.search();
  }
  
  search(){
  console.log(this.transactionForm.value.account);
		this.http.get('http://localhost:8090/bank-app/accounts/transaction/'+this.transactionForm.value.account).subscribe((res)=>{
            console.log(res);		
			this.dataSource = res;
        });	
  }

}
