# Angular7-Webpack4-Bootstrap4-Routing-Babel
Project on Angular7 bootstrap angluar routing with babel and encrypted with webpack

# System Requirements
Node.js, Angular cli at global

Step 1:- open terminal or CMD
Step 2:- npm install
Step 3: num start for live reload/ npm run build for production

