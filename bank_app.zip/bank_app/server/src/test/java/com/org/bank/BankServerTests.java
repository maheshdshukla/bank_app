package com.org.bank;

import java.math.BigDecimal;
import java.net.URI;
import java.net.URISyntaxException;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.org.bank.model.AccountEntity;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class BankServerTests {
	@LocalServerPort
	int randomServerPort;

//	@Test
//	public void testGetAccountListSuccess() throws URISyntaxException 
//	{
//	    RestTemplate restTemplate = new RestTemplate();
//	     
//	    final String baseUrl = "http://localhost:" + randomServerPort + "/bank-app/accounts";
//	    URI uri = new URI(baseUrl);
//	 
//	    ResponseEntity<String> result = restTemplate.getForEntity(uri, String.class);
//	     
//	    //Verify request succeed
//	    Assert.assertEquals(200, result.getStatusCodeValue());	    
//	    System.out.println(result.getBody());
//	}

//	@Test
//	public void testAddEmployeeMissingHeader() throws URISyntaxException 
//	{
//	    RestTemplate restTemplate = new RestTemplate();
//	    final String baseUrl = "http://localhost:"+randomServerPort+"/bank-app/accounts";
//	    URI uri = new URI(baseUrl);
//	    AccountEntity account = new AccountEntity("9555947580", new BigDecimal("1000"));
//	     
//	    HttpHeaders headers = new HttpHeaders();
//	 
//	    HttpEntity<AccountEntity> request = new HttpEntity<>(account, headers);
//	     
//	    try
//	    {
//	        restTemplate.postForEntity(uri, request, String.class);
//	        Assert.fail();
//	    }
//	    catch(HttpClientErrorException ex) 
//	    {
//	        //Verify bad request and missing header
//	        Assert.assertEquals(400, ex.getRawStatusCode());
//	        Assert.assertEquals(true, ex.getResponseBodyAsString().contains("Missing request header"));
//	    }
//	}

	@Test
	public void testTransaction() throws URISyntaxException {
		RestTemplate restTemplate = new RestTemplate();
		String baseUrl = "http://localhost:" + randomServerPort + "/bank-app/accounts";
		URI uri = new URI(baseUrl);

		for (int i = 0; i < 5; i++) {
			AccountEntity account1 = null;
			AccountEntity account2 = null;
			
			
			if (i == 0) {
				account1 = new AccountEntity("9555947583", new BigDecimal("100"));
				account2 = new AccountEntity("9555947584", new BigDecimal("100"));
			}
			if (i == 1) {
				account1 = new AccountEntity("9555947583", new BigDecimal("-200"));
				account2 = new AccountEntity("9555947584", new BigDecimal("200"));
			}
			if (i == 2) {
				account1 = new AccountEntity("9555947583", new BigDecimal("-10.11"));
				account2 = new AccountEntity("9555947584", new BigDecimal("10.11"));
			}
			if (i == 3) {
				account1 = new AccountEntity("9555947583", new BigDecimal("500"));
				account2 = new AccountEntity("9555947584", new BigDecimal("-500"));
			}

			if (i == 4) {
				account1 = new AccountEntity("9555947583", new BigDecimal("22.33"));
				account2 = new AccountEntity("9555947584", new BigDecimal("-22.33"));
			}

			HttpHeaders headers = new HttpHeaders();

			HttpEntity<AccountEntity> request1 = new HttpEntity<>(account1, headers);
			HttpEntity<AccountEntity> request2 = new HttpEntity<>(account2, headers);

			try {
				restTemplate.postForEntity(uri, request1, String.class).getBody();
				restTemplate.postForEntity(uri, request2, String.class).getBody();

			} catch (HttpClientErrorException ex) {
				// Verify bad request and missing header
				Assert.assertEquals(400, ex.getRawStatusCode());
				Assert.assertEquals(true, ex.getResponseBodyAsString().contains("Missing request header"));
			}
		}
			
		baseUrl = "http://localhost:" + randomServerPort + "/bank-app/accounts/transaction/9555947584";
	    uri = new URI(baseUrl);
	 
	    ResponseEntity<String> result = restTemplate.getForEntity(uri, String.class);
	     
	    //Verify request succeed
	    Assert.assertEquals(200, result.getStatusCodeValue());	    
	    System.out.println(result.getBody());
		
	}	
}
