package com.org.bank.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.org.bank.exception.RecordNotFoundException;
import com.org.bank.model.AccountEntity;
import com.org.bank.repository.AccountRepository;
import com.org.bank.heapler.TransactionHealper;

@Service
public class AccountService {

	@Autowired
	AccountRepository repository;
	
	@Autowired
	TransactionHealper transactionHealper;

	public List<AccountEntity> getAllAccounts() {
		List<AccountEntity> accountList = repository.findAll();

		if (accountList.size() > 0) {
			return accountList;
		} else {
			return new ArrayList<AccountEntity>();
		}
	}

	public AccountEntity getAccountById(Long id) throws RecordNotFoundException {
		Optional<AccountEntity> account = repository.findById(id);

		if (account.isPresent()) {
			return account.get();
		} else {
			throw new RecordNotFoundException("No account record exist for given id");
		}
	}

	public void payInAccount(Map<String, Object> account) throws RecordNotFoundException {

		AccountEntity newEntity = new AccountEntity(account.get("from").toString(),new BigDecimal("-"+account.get("amount").toString()));
		
		repository.save(newEntity);
		
		newEntity = new AccountEntity(account.get("to").toString(),new BigDecimal(account.get("amount").toString()));		
		repository.save(newEntity);
	}

	public void deleteAccountById(Long id) throws RecordNotFoundException {
		Optional<AccountEntity> account = repository.findById(id);

		if (account.isPresent()) {
			repository.deleteById(id);
		} else {
			throw new RecordNotFoundException("No account record exist for given id");
		}
	}

	public List getAccountTransactionById(String id) throws RecordNotFoundException {
		List account = repository.getAccountTransactionByAccount(id);
		
		List transactions = transactionHealper.processTransactionByAccountId(id,account);
				
		if (transactions.size() > 0) {
			return transactions;
		} else {
			throw new RecordNotFoundException("No account record exist for given id");
		}
	}

}