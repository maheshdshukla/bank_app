package com.org.bank.heapler;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.stereotype.Component;

import com.org.bank.model.AccountEntity;

@Component("transactionHealper")
public class TransactionHealper {

	public static List processTransactionByAccountId(String id, List<AccountEntity> accounts) {
	
		List transactionList =new ArrayList();
		
		final double[] count = new double[1];
		accounts.stream().forEach(e->{
			Map transactionTable = new HashMap();
			transactionTable.put("account", e.getAccount());
			if(e.getCredit().doubleValue() > 0) {
				transactionTable.put("credit", e.getCredit());
				transactionTable.put("debit", 0);
			}else {
				transactionTable.put("credit", 0);
				transactionTable.put("debit", e.getCredit());
			}
			count[0] = count[0] + e.getCredit().floatValue();	
			transactionTable.put("total", count[0]);
			transactionTable.put("date", e.getDate());
			transactionList.add(transactionTable);
		});					
		return transactionList;
	}
}
