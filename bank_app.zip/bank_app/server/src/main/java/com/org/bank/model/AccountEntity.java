package com.org.bank.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

@Entity
@Table(name = "TBL_ACCOUNTS")
public class AccountEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "account", nullable = false, length = 10)
	private String account;

	@Column(name = "credit", nullable = false, length = 15)
	private BigDecimal credit;

	@Column(name = "DATE")
	private Date date;

	@PreUpdate
	public void preUpdate() {
		date = new Date();
	}

	@PrePersist
	public void prePersist() {
		Date now = new Date();
		date = now;
	}
	
	public AccountEntity() {}
	
	public AccountEntity(String account,BigDecimal credit){
		this.account = account;
		this.credit = credit;
	}

	/**
	 * This setter method should only be used by unit tests.
	 * 
	 * @param id
	 */
	public void setId(Long id) {
		this.id = id;
	}

	public Long getId() {
		return id;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public BigDecimal getCredit() {
		return credit;
	}

	public void setCredit(BigDecimal credit) {
		this.credit = credit;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "[id=" + id + ", account =" + account + ", credit =" + credit + ", DATE =" + date + "]";
	}
}